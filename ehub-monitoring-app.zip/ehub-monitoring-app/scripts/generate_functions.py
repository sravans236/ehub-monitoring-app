#!/usr/bin/env python3
"""
Script to generate function configurations for all Event Hubs in a namespace
Run this during deployment to create monitoring functions for all Event Hubs
"""

import json
import os
import sys
from pathlib import Path

# Add parent directory to path
sys.path. append(str(Path(__file__).parent.parent))

from utils.config_manager import EventHubConfig, EventHubDiscovery


def generate_function_config(eventhub_name: str, output_dir: str):
    """Generate function. json for a specific Event Hub"""
    
    function_config = {
        "scriptFile": "../GenericEventHubMonitor/__init__.py",
        "bindings": [
            {
                "type": "eventHubTrigger",
                "name": "events",
                "direction": "in",
                "eventHubName": eventhub_name,
                "connection": "EventHubConnectionString",
                "consumerGroup": "%MonitorConsumerGroup%",
                "cardinality": "many",
                "dataType": "binary"
            }
        ]
    }
    
    # Create function directory
    function_dir = Path(output_dir) / f"Monitor_{eventhub_name. replace('-', '_')}"
    function_dir.mkdir(parents=True, exist_ok=True)
    
    # Write function.json
    config_path = function_dir / "function.json"
    with open(config_path, 'w') as f:
        json. dump(function_config, f, indent=2)
    
    print(f"Generated function config:  {config_path}")
    
    return str(function_dir)


def main():
    """Main entry point"""
    print("Discovering Event Hubs in namespace...")
    
    # Initialize configuration
    config = EventHubConfig()
    
    if not config.validate():
        print("ERROR: Configuration validation failed")
        print("Required environment variables:")
        print("  - EventHubConnectionString")
        print("  - EventHubNamespace")
        print("  - ResourceGroup")
        print("  - SubscriptionId")
        sys.exit(1)
    
    # Initialize discovery
    discovery = EventHubDiscovery(config)
    
    # Get all Event Hubs
    eventhubs = discovery.get_all_eventhubs()
    
    if not eventhubs:
        print("No Event Hubs found in namespace")
        sys.exit(1)
    
    print(f"Found {len(eventhubs)} Event Hubs:")
    for eh in eventhubs:
        print(f"  - {eh['name']} ({eh['partitionCount']} partitions)")
    
    # Generate function configurations
    output_dir = Path(__file__).parent.parent
    
    for eh in eventhubs:
        generate_function_config(eh['name'], str(output_dir))
    
    print(f"\nGenerated {len(eventhubs)} function configurations")
    print("\nNext steps:")
    print("  1. Review generated function directories")
    print("  2. Deploy the function app")
    print("  3. Monitor logs in Application Insights")


if __name__ == "__main__":
    main()