import os
import sys
from utils.eventhub_discovery import discover_eventhubs

# Set environment variables
os.environ["EventHubConnectionString"] = "YOUR_CONNECTION_STRING"
os.environ["SubscriptionId"] = "YOUR_SUBSCRIPTION_ID"  # Optional
os.environ["ResourceGroup"] = "YOUR_RESOURCE_GROUP"  # Optional

# Test discovery
eventhub_names = discover_eventhubs(
    connection_string=os.environ["EventHubConnectionString"],
    subscription_id=os.environ. get("SubscriptionId"),
    resource_group=os.environ.get("ResourceGroup"),
    fallback_names=["eventhub1", "eventhub2"]  # Optional fallback
)

print(f"\nDiscovered Event Hubs: {len(eventhub_names)}")
for name in eventhub_names: 
    print(f"  - {name}")
