import logging
import azure.functions as func
from datetime import datetime
import json
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from utils.config_manager import EventHubConfig, EventHubDiscovery
from utils.logger import EventHubMonitorLogger


def main(timer: func.TimerRequest) -> None:
    """
    Timer-triggered function to discover and monitor all Event Hubs 
    and Consumer Groups in the namespace
    
    Runs every 5 minutes by default
    """
    logger = logging.getLogger("NamespaceDiscovery")
    monitor_logger = EventHubMonitorLogger(logger)
    
    utc_timestamp = datetime.utcnow().isoformat()
    logger.info(f"Namespace Discovery Function triggered at {utc_timestamp}")
    
    # Initialize configuration
    config = EventHubConfig()
    
    if not config.validate():
        logger.error("Configuration validation failed.  Check environment variables.")
        return
    
    # Initialize discovery service
    discovery = EventHubDiscovery(config)
    
    try:
        # ============================================
        # DISCOVER ALL EVENT HUBS IN NAMESPACE
        # ============================================
        
        logger.info(f"Discovering Event Hubs in namespace: {config.namespace}")
        
        # Get complete namespace overview
        namespace_overview = discovery.get_namespace_overview()
        
        # Log namespace overview
        monitor_logger.log_namespace_overview(namespace_overview)
        
        logger.info(
            f"Discovered {namespace_overview['totalEventHubs']} Event Hubs, "
            f"{namespace_overview['totalConsumerGroups']} Consumer Groups, "
            f"{namespace_overview['totalPartitions']} total partitions"
        )
        
        # ============================================
        # MONITOR EACH EVENT HUB AND CONSUMER GROUP
        # ============================================
        
        for eventhub in namespace_overview["eventhubs"]:
            eventhub_name = eventhub["name"]
            logger.info(f"Monitoring Event Hub: {eventhub_name}")
            
            # Monitor each consumer group
            for cg in eventhub["consumerGroups"]:
                consumer_group_name = cg["name"]
                
                logger.info(
                    f"  Monitoring Consumer Group: {consumer_group_name} "
                    f"on Event Hub: {eventhub_name}"
                )
                
                # Get partition information for this consumer group
                partition_info = discovery.get_partition_info(
                    eventhub_name=eventhub_name,
                    consumer_group=consumer_group_name
                )
                
                # Log consumer group details
                monitor_logger. log_consumer_group_details(
                    eventhub_name=eventhub_name,
                    consumer_group=consumer_group_name,
                    partition_info=partition_info
                )
                
                # Log summary for each partition
                for partition in partition_info:
                    logger.info(
                        f"    Partition {partition['partitionId']}: "
                        f"LastSeq={partition['lastEnqueuedSequenceNumber']}, "
                        f"LastOffset={partition['lastEnqueuedOffset']}, "
                        f"LastTime={partition['lastEnqueuedTimeUtc']}, "
                        f"IsEmpty={partition['isEmpty']}"
                    )
        
        logger.info("Namespace discovery and monitoring complete")
    
    except Exception as e: 
        logger.error(f"Error in namespace discovery: {str(e)}", exc_info=True)