import logging
import json
import azure.functions as func
from datetime import datetime
import time
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from utils.logger import EventHubMonitorLogger


def main(events: func.EventHubEvent):
    """
    Generic Event Hub monitor that works for ANY Event Hub
    
    Configure multiple instances of this function for different Event Hubs
    by deploying with different function. json configurations
    """
    start_time = time.time()
    
    logger = logging.getLogger("GenericEventHubMonitor")
    monitor_logger = EventHubMonitorLogger(logger)
    
    batch_size = len(events)
    
    # Get Event Hub name from environment or event metadata
    eventhub_name = os.environ.get("EVENTHUB_NAME", "unknown")
    
    logger.info(f"Processing batch of {batch_size} events from Event Hub: {eventhub_name}")
    
    sequence_numbers = []
    offsets = []
    partition_id = "unknown"
    
    for event in events:
        try:
            # Extract metadata
            sequence_number = event.sequence_number
            offset = event. offset
            partition_key = event.partition_key
            enqueued_time = event.enqueued_time
            
            sequence_numbers.append(sequence_number)
            offsets.append(offset)
            
            metadata = event.metadata or {}
            partition_context = metadata.get('PartitionContext', {})
            partition_id = partition_context.get('PartitionId', 'unknown')
            
            # Try to extract Event Hub name from metadata
            if eventhub_name == "unknown":
                eventhub_name = metadata.get('SystemProperties', {}).get('EnqueuedTimeUtc', {}).get('EntityPath', 'unknown')
            
            system_properties = event.system_properties or {}
            correlation_id = system_properties.get('correlation-id')
            message_id = system_properties.get('message-id')
            content_type = system_properties.get('content-type')
            
            user_properties = {}
            if hasattr(event, 'properties') and event.properties:
                user_properties = dict(event.properties)
            
            raw_payload_bytes = event.get_body()
            payload_size = len(raw_payload_bytes)
            
            try:
                raw_payload = raw_payload_bytes.decode('utf-8')
                payload_truncated = raw_payload[:1000] + ("..." if len(raw_payload) > 1000 else "")
            except UnicodeDecodeError:
                payload_truncated = f"<binary data:  {raw_payload_bytes[: 100]. hex()}...>"
            
            # Log event details
            monitor_logger.log_event_details(
                eventhub_name=eventhub_name,
                sequence_number=sequence_number,
                offset=offset,
                partition_key=partition_key,
                enqueued_time=enqueued_time,
                partition_id=partition_id,
                payload_truncated=payload_truncated,
                payload_size=payload_size,
                correlation_id=correlation_id,
                message_id=message_id,
                content_type=content_type,
                system_properties=system_properties,
                user_properties=user_properties
            )
        
        except Exception as e: 
            logger.error(f"Error processing event: {str(e)}", exc_info=True)
    
    # Log batch metrics
    processing_time_ms = (time. time() - start_time) * 1000
    
    if sequence_numbers and offsets:
        monitor_logger.log_processing_metrics(
            eventhub_name=eventhub_name,
            batch_size=batch_size,
            processing_time_ms=processing_time_ms,
            partition_id=partition_id,
            first_sequence_number=min(sequence_numbers),
            last_sequence_number=max(sequence_numbers),
            first_offset=min(offsets),
            last_offset=max(offsets)
        )
    
    logger.info(
        f"Batch complete: EventHub={eventhub_name}, "
        f"{batch_size} events in {processing_time_ms:.2f}ms"
    )