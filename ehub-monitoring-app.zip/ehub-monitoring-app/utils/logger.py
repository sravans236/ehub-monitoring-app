import logging
import json
from datetime import datetime
from typing import Dict, Any, Optional, List

class EventHubMonitorLogger: 
    def __init__(self, logger:  logging.Logger):
        self.logger = logger
    
    def log_event_details(
        self,
        eventhub_name: str,
        sequence_number: int,
        offset: str,
        partition_key: Optional[str],
        enqueued_time: datetime,
        partition_id: str,
        payload_truncated: str,
        payload_size: int,
        correlation_id: Optional[str] = None,
        message_id:  Optional[str] = None,
        content_type: Optional[str] = None,
        system_properties: Dict[str, Any] = None,
        user_properties: Dict[str, Any] = None
    ):
        """Log comprehensive Event Hub event details"""
        
        event_details = {
            "eventType": "EventHubMessage",
            "timestamp": datetime.utcnow().isoformat(),
            "eventhubName": eventhub_name,
            
            "systemProperties": {
                "sequenceNumber": sequence_number,
                "offset":  offset,
                "partitionKey": partition_key,
                "enqueuedTimeUtc": enqueued_time.isoformat() if enqueued_time else None,
                "partitionId":  partition_id,
            },
            
            "messageProperties": {
                "correlationId": correlation_id,
                "messageId": message_id,
                "contentType": content_type,
            },
            
            "payload": {
                "truncated":  payload_truncated,
                "sizeBytes": payload_size,
            },
            
            "userProperties": user_properties or {},
            "additionalSystemProperties": system_properties or {}
        }
        
        self. logger.info(f"Event Details: {json.dumps(event_details, default=str)}")
        return event_details
    
    def log_namespace_overview(self, overview: Dict[str, Any]):
        """Log namespace discovery overview"""
        overview_log = {
            "eventType": "NamespaceOverview",
            "timestamp": datetime.utcnow().isoformat(),
            "overview": overview
        }
        self.logger.info(f"Namespace Overview: {json.dumps(overview_log, default=str)}")
        return overview_log
    
    def log_consumer_group_details(
        self,
        eventhub_name: str,
        consumer_group: str,
        partition_info: List[Dict[str, Any]]
    ):
        """Log consumer group partition details"""
        cg_details = {
            "eventType": "ConsumerGroupDetails",
            "timestamp": datetime. utcnow().isoformat(),
            "eventhubName": eventhub_name,
            "consumerGroup": consumer_group,
            "partitions": partition_info,
            "partitionCount": len(partition_info)
        }
        self. logger.info(f"Consumer Group Details: {json.dumps(cg_details, default=str)}")
        return cg_details
    
    def log_processing_metrics(
        self,
        eventhub_name: str,
        batch_size: int,
        processing_time_ms: float,
        partition_id: str,
        first_sequence_number: int = None,
        last_sequence_number: int = None,
        first_offset: str = None,
        last_offset: str = None
    ):
        """Log batch processing metrics"""
        metrics = {
            "eventType": "ProcessingMetrics",
            "eventhubName": eventhub_name,
            "batchSize": batch_size,
            "processingTimeMs": processing_time_ms,
            "partitionId": partition_id,
            "sequenceNumberRange": {
                "first": first_sequence_number,
                "last": last_sequence_number,
                "span": last_sequence_number - first_sequence_number if (first_sequence_number and last_sequence_number) else 0
            },
            "offsetRange": {
                "first":  first_offset,
                "last": last_offset
            },
            "timestamp": datetime.utcnow().isoformat()
        }
        self.logger.info(f"Processing Metrics: {json. dumps(metrics, default=str)}")
        return metrics