import os
import logging
from typing import List, Dict, Any
from azure.identity import DefaultAzureCredential, ClientSecretCredential
from azure. mgmt.eventhub import EventHubManagementClient
from azure.eventhub import EventHubConsumerClient

logger = logging.getLogger("ConfigManager")


class EventHubConfig:
    """Configuration for Event Hub namespace and resources"""
    
    def __init__(self):
        # Connection settings
        self.connection_string = os.environ.get("EventHubConnectionString")
        self.namespace = os.environ.get("EventHubNamespace")
        self.resource_group = os.environ.get("ResourceGroup")
        self.subscription_id = os.environ.get("SubscriptionId")
        
        # Monitoring consumer group for this function
        self.monitor_consumer_group = os.environ.get("MonitorConsumerGroup", "$Monitor")
        
        # Authentication
        self.credential = self._get_credential()
    
    def _get_credential(self):
        """Get Azure credential"""
        try:
            # Try Managed Identity first (recommended for production)
            return DefaultAzureCredential()
        except Exception as e:
            logger.warning(f"Failed to get DefaultAzureCredential: {e}")
            
            # Fallback to Service Principal if configured
            client_id = os.environ.get("AZURE_CLIENT_ID")
            client_secret = os.environ. get("AZURE_CLIENT_SECRET")
            tenant_id = os.environ.get("AZURE_TENANT_ID")
            
            if client_id and client_secret and tenant_id:
                return ClientSecretCredential(
                    tenant_id=tenant_id,
                    client_id=client_id,
                    client_secret=client_secret
                )
            
            return None
    
    def validate(self) -> bool:
        """Validate required configuration"""
        required = [
            self.connection_string,
            self.namespace,
            self.resource_group,
            self.subscription_id
        ]
        return all(required)


class EventHubDiscovery:
    """Discovers all Event Hubs and Consumer Groups in a namespace"""
    
    def __init__(self, config: EventHubConfig):
        self.config = config
        self.mgmt_client = None
        
        if config.credential and config.subscription_id:
            self.mgmt_client = EventHubManagementClient(
                credential=config.credential,
                subscription_id=config.subscription_id
            )
    
    def get_all_eventhubs(self) -> List[Dict[str, Any]]:
        """Get all Event Hubs in the namespace"""
        eventhubs = []
        
        try: 
            if not self.mgmt_client:
                logger.error("Management client not initialized")
                return eventhubs
            
            eventhubs_list = self.mgmt_client.event_hubs.list_by_namespace(
                resource_group_name=self.config.resource_group,
                namespace_name=self.config.namespace
            )
            
            for eh in eventhubs_list: 
                eventhub_info = {
                    "name":  eh.name,
                    "partitionCount": eh.partition_count,
                    "status": eh.status,
                    "createdAt": eh.created_at. isoformat() if eh.created_at else None,
                    "updatedAt": eh.updated_at.isoformat() if eh.updated_at else None,
                    "partitionIds": eh.partition_ids or []
                }
                eventhubs.append(eventhub_info)
                logger.info(f"Discovered Event Hub: {eh.name} with {eh.partition_count} partitions")
        
        except Exception as e: 
            logger.error(f"Error discovering Event Hubs: {str(e)}", exc_info=True)
        
        return eventhubs
    
    def get_all_consumer_groups(self, eventhub_name: str) -> List[Dict[str, Any]]:
        """Get all consumer groups for a specific Event Hub"""
        consumer_groups = []
        
        try:
            if not self.mgmt_client:
                logger.error("Management client not initialized")
                return consumer_groups
            
            cg_list = self.mgmt_client.consumer_groups.list_by_event_hub(
                resource_group_name=self.config.resource_group,
                namespace_name=self.config.namespace,
                event_hub_name=eventhub_name
            )
            
            for cg in cg_list:
                cg_info = {
                    "name": cg.name,
                    "eventhubName": eventhub_name,
                    "createdAt": cg.created_at.isoformat() if cg.created_at else None,
                    "updatedAt":  cg.updated_at.isoformat() if cg.updated_at else None,
                    "userMetadata": cg. user_metadata
                }
                consumer_groups. append(cg_info)
        
        except Exception as e: 
            logger.error(f"Error getting consumer groups for {eventhub_name}: {str(e)}", exc_info=True)
        
        return consumer_groups
    
    def get_partition_info(
        self,
        eventhub_name:  str,
        consumer_group: str = "$Default"
    ) -> List[Dict[str, Any]]: 
        """Get partition information and checkpoints for a consumer group"""
        partition_info = []
        
        try: 
            # Create consumer client for this specific Event Hub
            client = EventHubConsumerClient. from_connection_string(
                conn_str=self.config.connection_string,
                consumer_group=consumer_group,
                eventhub_name=eventhub_name
            )
            
            # Get Event Hub properties
            eventhub_props = client.get_eventhub_properties()
            
            # Get partition IDs
            partition_ids = client.get_partition_ids()
            
            for partition_id in partition_ids: 
                try:
                    # Get partition properties
                    partition_props = client.get_partition_properties(partition_id)
                    
                    info = {
                        "eventhubName": eventhub_name,
                        "consumerGroup": consumer_group,
                        "partitionId": partition_id,
                        "lastEnqueuedSequenceNumber": partition_props. last_enqueued_sequence_number,
                        "lastEnqueuedOffset": partition_props.last_enqueued_offset,
                        "lastEnqueuedTimeUtc": partition_props.last_enqueued_time_utc. isoformat() if partition_props.last_enqueued_time_utc else None,
                        "beginningSequenceNumber": partition_props.beginning_sequence_number,
                        "isEmpty": partition_props.is_empty
                    }
                    
                    partition_info.append(info)
                
                except Exception as e:
                    logger.error(f"Error getting partition {partition_id} info: {str(e)}")
            
            client.close()
        
        except Exception as e: 
            logger.error(f"Error connecting to Event Hub {eventhub_name}: {str(e)}")
        
        return partition_info
    
    def get_namespace_overview(self) -> Dict[str, Any]:
        """Get complete overview of the namespace"""
        overview = {
            "namespace": self.config.namespace,
            "discoveryTime": None,
            "eventhubs":  [],
            "totalEventHubs": 0,
            "totalConsumerGroups": 0,
            "totalPartitions": 0
        }
        
        from datetime import datetime
        overview["discoveryTime"] = datetime. utcnow().isoformat()
        
        # Discover all Event Hubs
        eventhubs = self.get_all_eventhubs()
        overview["totalEventHubs"] = len(eventhubs)
        
        for eh in eventhubs:
            eh_data = {
                "name": eh["name"],
                "partitionCount": eh["partitionCount"],
                "status": eh["status"],
                "consumerGroups": []
            }
            
            overview["totalPartitions"] += eh["partitionCount"]
            
            # Get consumer groups for this Event Hub
            consumer_groups = self.get_all_consumer_groups(eh["name"])
            eh_data["consumerGroups"] = consumer_groups
            overview["totalConsumerGroups"] += len(consumer_groups)
            
            overview["eventhubs"].append(eh_data)
        
        return overview